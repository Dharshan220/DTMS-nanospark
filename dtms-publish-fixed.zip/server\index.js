import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;
const uploadDir = path.join(__dirname, "uploads");
const dataFile = path.join(__dirname, "feedback.json");

await fs.mkdir(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, "_")}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2 MB
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Only image uploads are allowed."));
    }
    cb(null, true);
  },
});

app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(",") || "*", credentials: true }));
app.use(express.json({ limit: "3mb" }));
app.use("/uploads", express.static(uploadDir));

async function readFeedback() {
  try {
    const data = await fs.readFile(dataFile, "utf8");
    return JSON.parse(data);
  } catch (err) {
    if (err.code === "ENOENT") return [];
    console.error("Error reading feedback store", err);
    return [];
  }
}

async function writeFeedback(entries) {
  await fs.writeFile(dataFile, JSON.stringify(entries, null, 2), "utf8");
}

app.get("/api/feedback", async (_req, res) => {
  const items = await readFeedback();
  res.json(items);
});

app.post("/api/feedback", upload.single("image"), async (req, res) => {
  const { name = "Anonymous", department, year, section, routeNumber = "", category, description } = req.body;

  if (!department || !year || !section || !category || !description) {
    return res.status(400).json({ message: "Missing required fields." });
  }

  const entry = {
    id: Date.now(),
    name: String(name).trim() || "Anonymous",
    department: String(department).trim(),
    year: String(year),
    section: String(section).trim(),
    routeNumber: String(routeNumber),
    category: String(category),
    description: String(description).trim(),
    imageUrl: req.file ? `/uploads/${req.file.filename}` : null,
    imageName: req.file ? req.file.originalname : null,
    timestamp: new Date().toISOString(),
  };

  const items = await readFeedback();
  items.unshift(entry);
  await writeFeedback(items);

  res.status(201).json(entry);
});

// Admin Login Route
const admins = [
  { username: "admin1", password: "password123" },
  { username: "admin2", password: "securepass456" },
  { username: "admin3", password: "adminpass789" },
  { username: "superadmin", password: "superpassword1" },
  { username: "masteradmin", password: "masterpassword2" }
];

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required." });
  }
  
  const admin = admins.find(a => a.username === username && a.password === password);
  if (admin) {
    return res.status(200).json({ message: "Login successful", username: admin.username });
  } else {
    return res.status(401).json({ message: "Invalid username or password" });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({ message: "Image too large. Max 2 MB." });
  }
  return res.status(400).json({ message: err.message || "Upload error." });
});

app.listen(PORT, () => {
  console.log(`Feedback API running at http://localhost:${PORT}`);
});
