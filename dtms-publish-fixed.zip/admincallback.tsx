import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'sonner';

export function AdminCallback() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get parameters from URL
        const email = searchParams.get('email');
        const token = searchParams.get('token');
        const provider = searchParams.get('provider');

        console.log('Callback received:', { email, token, provider });

        if (!email || !token) {
          console.error('Missing email or token in callback');
          toast.error('Login failed: Missing credentials');
          navigate('/admin-login');
          return;
        }

        // Verify email with backend
        try {
          const response = await axios.post('http://localhost:4000/api/auth/verify-email', {
            email: email
          });

          console.log('Verification response:', response.data);

          // Save to localStorage
          localStorage.setItem('adminEmail', response.data.admin.email);
          localStorage.setItem('adminToken', response.data.token);
          localStorage.setItem('adminName', response.data.admin.name);
          localStorage.setItem('adminPicture', response.data.admin.picture || '');
          localStorage.setItem('adminRole', response.data.admin.role);
          localStorage.setItem('adminProvider', provider || 'google');

          console.log('Saved to localStorage:', {
            email: response.data.admin.email,
            name: response.data.admin.name
          });

          toast.success(`Welcome, ${response.data.admin.name}! 🎉`);
          
          // Redirect to admin dashboard
          navigate('/admin-dashboard');
        } catch (verifyError: any) {
          console.error('Verification error:', verifyError);
          
          // If email not found, create new admin
          if (verifyError.response?.status === 404) {
            // For first-time login, create admin with this email
            localStorage.setItem('adminEmail', email);
            localStorage.setItem('adminToken', token);
            localStorage.setItem('adminName', email.split('@')[0]);
            localStorage.setItem('adminPicture', '');
            localStorage.setItem('adminRole', 'admin');
            localStorage.setItem('adminProvider', provider || 'google');

            toast.success(`Welcome, ${email}! 🎉`);
            navigate('/admin-dashboard');
          } else {
            toast.error(verifyError.response?.data?.error || 'Login failed');
            navigate('/admin-login');
          }
        }
      } catch (error: any) {
        console.error('Callback error:', error);
        toast.error('Login callback failed');
        navigate('/admin-login');
      }
    };

    handleCallback();
  }, [searchParams, navigate]);

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
      <div style={{ textAlign: 'center' }}>
        <h2>Logging in...</h2>
        <p>Please wait while we verify your credentials</p>
      </div>
    </div>
  );
}
